function [ output_args ] = generator_5channel( config ,folder)

c = 340;                    % Sound velocity (m/s)
fs = 16000;                 % Sample frequency (samples/s)
           % Room dimensions [x y z] (m)
n = 4096;                   % Number of samples
              % Reverberation time (s)���������ɳ��У���Ӧд�� [0,0,0]
mtype = 'omnidirectional';    % Type of microphone
order = -1;                 % -1 equals maximum reflection order!
dim = 3;                    % Room dimension
orientation = pi/2;         % Microphone orientation (rad)
hp_filter = 0;       
data=importdata(config);
T60=data(1,:);
x1=data(2,:);
y1=data(3,:);
z1=data(4,:);
r1=data(5,:);
thi1=data(6,:)/180*pi;
phi1=data(7,:)/180*pi;
mkdir(folder);
tf_inf=fullfile(folder,'inf.list');
fid=fopen(tf_inf,'wt+');
ns_num_all=[];
beta_T60=T60(1):T60(2):T60(3);
beta_len=length(beta_T60)

for i=1:beta_len
beta=beta_T60(i);
for d=r1(1):r1(2):r1(3)
    for x=x1(1):x1(2):x1(3)
        for y=y1(1):y1(2):y1(3)
            for z=z1(1):z1(2):z1(3)
               
               L = [x y z];  
               xr=rand(1,1)*(x-1)+0.5;
               yr=rand(1,1)*(y-1)+0.5;
               zr=rand(1,1)*(z-1)+0.5;
               r=[xr yr zr];
               for thi=thi1(1):thi1(2):thi1(3)
                   for phi=phi1(1):phi1(2):phi1(3)
                       xs=xr+d*cos(phi)*cos(thi);
                       ys=yr+d*cos(phi)*sin(thi);
                       zs=zr+d*sin(phi);
                       
                       if xs>0.5  & xs<(x-0.5) & ys>0.5  & ys<(y-0.5) & zs<(z-0.5) & zs>0.5
                        
                        trmr=zeros(4096,8);
                        s=[xs ys zs];
                      
                        beta_str=num2str(beta);
                        d_str=num2str(d);
                        thi_str=num2str(thi/pi*180);
                        phi_str=num2str(phi/pi*180);
                        x_str=num2str(x);
                        y_str=num2str(y);
                        z_str=num2str(z);
                        trmr1 = rir_generator(c, fs, r, s, L, beta, n, mtype,order,dim,orientation,hp_filter);
                        trmr1=trmr1(:);
                        r_next=[xr-0.04 yr zr];
                        trmr2= rir_generator(c,fs,r_next,s,L,beta,n,mtype,order,dim,orientation,hp_filter);
                        trmr2=trmr2(:);
                       trmr(:,1)=trmr1;
                       trmr(:,2)=trmr2;
                      ns_num=0;
                       for ns_idx=1:3
                          ns_thi=rand(1,1)*2*pi;
                          ns_phi=rand(1,1)*(pi/2+pi/3)-pi/3;
                          ns_d=rand(1,1)*5+1;
                          xs=xr+ns_d*cos(ns_phi)*cos(ns_thi);
                          ys=yr+ns_d*cos(ns_phi)*sin(ns_thi);
                          zs=zr+ns_d*sin(ns_phi);
                          if xs>0.5  & xs<(x-0.5) & ys>0.5  & ys<(y-0.5) & zs<(z-0.5) & zs>0.5
                           s=[xs ys zs];
                           trmr1 = rir_generator(c, fs, r, s, L, beta, n, mtype,order,dim,orientation,hp_filter);
                           trmr1=trmr1(:);
                           trmr2= rir_generator(c,fs,r_next,s,L,beta,n,mtype,order,dim,orientation,hp_filter);
                           trmr2=trmr2(:);
                           trmr(:,2+2*(ns_idx-1)+1)=trmr1;
                           trmr(:,2+2*(ns_idx-1)+2)=trmr2;
                           ns_num=ns_num+1;
                           end

                       end
                       ns_num_all=[ns_num_all;ns_num];

                       
                       sp_name = sprintf('T60_%s_%s_%s_%s_%s_%s_%s.mat',beta_str,d_str,thi_str,phi_str,x_str,y_str,z_str);
                       sp_name1=fullfile(folder,sp_name);
                       save(sp_name1,'trmr');
                       fprintf(fid,'%s ',sp_name1);
                       fprintf(fid,'{T60:%s}',beta_str);
                        fprintf(fid,'{dis:%s}',d_str);
                       fprintf(fid,'{thi:%s}',thi_str);
                       fprintf(fid,'{phi:%s}',phi_str);
                       fprintf(fid,'{x:%s}{y:%s}{z:%s}\n',x_str,y_str,z_str);
                       end
                   end 
               end
            %   h = rir_generator(c, fs, r, s, L, beta, n, mtype,order,dim,orientation,hp_filter);
               
            end
        end
    end
end
end

fclose(fid);
sp_name='num.mat';
spname1=fullfile(folder,sp_name);
save(spname1,'ns_num_all');
end

