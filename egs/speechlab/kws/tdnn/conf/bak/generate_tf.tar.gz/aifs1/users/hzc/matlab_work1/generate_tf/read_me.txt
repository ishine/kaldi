生成卷积函数：  generator_tf(arg1,arg2)
输入：两个参数 arg1 , arg2
arg1: 房间参数
参数格式见本目录下的config
第一列为T60
第二列为房间长度
第三列为房间宽度
第四列为房间高度
第五列为人距麦克风的距离
第六列水平角（角度制）
第七列高度角（角度制）
0.2 0.1 0.8
6 0.5 10
6.5 0.5 8
3 0.5 5
1 1 4
0 22.5 360
-45 22.5 45
arg2：生成的卷积核所放的文件目录
例子 generator_tf('aifs1/users/hzc/matlab_work/config','/aifs1/users/hzc/tf/2000h_tf');

